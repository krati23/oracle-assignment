package com.helidon.oracle.assignment.main;

import java.util.List;

import com.helidon.oracle.assignment.data.PokemonJpa;
import com.helidon.oracle.assignment.entity.Pokemon;

public class PokemonMain {

	public static void main(String[] args) {
		PokemonJpa.createPokemonEntity("1","testpokemon", "A",1);
		
		List<Pokemon> list =PokemonJpa.getAllPokemon();
		System.out.println("Retrieving list of  pokemon"+list);
		
		Pokemon pokemon =PokemonJpa.getPokemonById("1");
		System.out.println("Retrieving pokemon"+pokemon);
		
		System.out.println("Deleting pokemon");
		PokemonJpa.deletePokemonRecord("1");
		
		Pokemon pokemonObjByType =PokemonJpa.getPokemonByType("A");
		System.out.println("Retrieving Pokemon By Type"+pokemonObjByType);
		
	}

}

