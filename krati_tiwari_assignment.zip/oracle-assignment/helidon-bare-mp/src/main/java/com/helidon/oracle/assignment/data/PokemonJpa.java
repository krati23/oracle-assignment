package com.helidon.oracle.assignment.data;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.helidon.oracle.assignment.entity.Pokemon;

import jakarta.transaction.Transactional;

@Dependent	
public class PokemonJpa {
	
	@PersistenceContext 
	private EntityManager em;
	
	//Get Pokemon By ID
	@GET
	@Path("pokemon/{Id}")
	@Produces("text/plain")
	@Transactional 
	public static Pokemon getPokemonById(@PathParam("Id") String id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pokemon");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
	    Pokemon pokemon = em.find(Pokemon.class, id);
	    em.getTransaction().commit();
	    return pokemon;
	}
	
	//Get the list of Pokemon
	
	@GET
	@Path("pokemon/getAll")
	@Transactional
	public static List<Pokemon> getAllPokemon(){
		List<Pokemon> list = new ArrayList<>();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pokemon");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		list=em.createNamedQuery("Pokemon.findAll").getResultList();
		em.getTransaction().commit();
		return list;
	}

	//create the pokemon object
	@POST
	@Consumes("text/plain")
	@Transactional
	public static void createPokemonEntity(String id,String name,String type,int arge) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pokemon");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Pokemon obj = new Pokemon(id,name,type,arge);
		em.persist(obj);
		em.getTransaction().commit();
	}
	
	//get the pokemon by Type
	
	@GET
	@Path("pokemon/{Type}")
	@Produces("text/plain")
	@Transactional 
	public static Pokemon getPokemonByType(@PathParam("Type") String type) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pokemon");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
	    Pokemon pokemon = em.find(Pokemon.class, type);
	    em.getTransaction().commit();
	    return pokemon;
	    
	}
	
	//delete the pokemon
	@DELETE
	@Path("pokemon/delete/{id}")
	@Transactional
	public static void deletePokemonRecord(@PathParam("Id") String id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pokemon");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Pokemon obj = em.find(Pokemon.class,id);
		em.remove(obj);
		em.getTransaction().commit();
		
		 
	}
	
	
	
}
