package com.helidon.oracle.assignment.entity;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Access(value = AccessType.FIELD) 
@Entity(name = "Pokemon") 
@Table(name = "POKEMON")
public class Pokemon implements Serializable {
	
	@Column(
	        insertable = true,
	        name = "ID", 
	        nullable = false,
	        updatable = false
	    )
	@Id
	private String id;
	
	@Basic(optional = false)
	@Column(
	        insertable = true,
	        name = "NAME",
	        nullable = false,
	        updatable = true
	    )
	private String name;
	
	@Basic(optional = false)
	@Column(
	        insertable = true,
	        name = "TYPE",
	        nullable = false,
	        updatable = true
	    )
	private String type;
	
	@Basic(optional = false)
	@Column(
	        insertable = true,
	        name = "ARGE",
	        nullable = false,
	        updatable = true
	    )
	private int arge;
	
	//added constructors
	
	protected Pokemon() { 
        super();
    }

	public Pokemon(String id, String name, String type, int arge) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.arge = arge;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getArge() {
		return arge;
	}

	public void setArge(int arge) {
		this.arge = arge;
	}

	@Override
	public String toString() {
		return "Pokemon [id=" + id + ", name=" + name + ", type=" + type + ", arge=" + arge + "]";
	}
	
	
	
	
	
	
	

}
